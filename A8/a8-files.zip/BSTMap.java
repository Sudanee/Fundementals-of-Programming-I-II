import java.util.*;

public class BSTMap<K extends Comparable<K>, V > implements  Map<K, V>  {

	BinarySearchTree<K,V> bst;

	public BSTMap () {
		bst = new BinarySearchTree<K,V>();
	}

	public boolean containsKey(K key) {
		return false; // so it compiles
	}

	public V get (K key) throws KeyNotFoundException {
		throw new KeyNotFoundException(); // so it compiles
	}

	public List<Entry<K,V>>	entryList() {
		return null; // so it compiles
	}

	public void put (K key, V value) {
		
	}

	public int size() {
		return -1; // so it compiles
	}

	public void clear() {
		
	}


	// The remaining methods are for Part III:
	public long getGetLoopCount() {
		return bst.getFindLoopCount();
	}

	public long getPutLoopCount() {
		return bst.getInsertLoopCount();
	}

	public void resetGetLoops() {
		bst.resetFindLoops();
	}
	public void resetPutLoops() {
		bst.resetInsertLoops();
	}
}
